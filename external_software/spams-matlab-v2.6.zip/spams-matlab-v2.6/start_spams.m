addpath('test_release');
addpath('src_release');
addpath('build');
setenv('MKL_NUM_THREADS','1')
setenv('MKL_SERIAL','YES')
setenv('MKL_DYNAMIC','NO')
